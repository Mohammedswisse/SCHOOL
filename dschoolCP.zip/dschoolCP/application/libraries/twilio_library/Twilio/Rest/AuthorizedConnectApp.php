<?php

class Services_Twilio_Rest_AuthorizedConnectApp
    extends Services_Twilio_InstanceResource
{
}
