<!-- Footer -->
<footer class="main">
	&copy; 2023 
	<a href="mailto:info@j1hostsolution.com"
    	target="_blank"><?php echo get_settings('system_name'); ?></a>
</footer>
