<form class="" action="<?php echo base_url() . 'index.php/student/attendance_report_selector/'; ?>" method="post">
<div class="panel panel-primary">
    <div class="panel-heading">
        <h3 class="panel-title"><?php echo get_phrase('attendance_of') ?></h3>
    </div>
    <div class="panel-body">
        <div class="row">
            <div class="col-md-offset-3 col-md-3">
                 <div class="form-group">
                    <label class="control-label" style="margin-bottom: 5px;"><?php echo get_phrase('month'); ?></label>
                    <select name="month" class="form-control selectboxit">
                        <?php
                        for ($i = 1; $i <= 12; $i++):
                            if ($i == 1)
                                $m = 'january';
                            else if ($i == 2)
                                $m = 'february';
                            else if ($i == 3)
                                $m = 'march';
                            else if ($i == 4)
                                $m = 'april';
                            else if ($i == 5)
                                $m = 'may';
                            else if ($i == 6)
                                $m = 'june';
                            else if ($i == 7)
                                $m = 'july';
                            else if ($i == 8)
                                $m = 'august';
                            else if ($i == 9)
                                $m = 'september';
                            else if ($i == 10)
                                $m = 'october';
                            else if ($i == 11)
                                $m = 'november';
                            else if ($i == 12)
                                $m = 'december';
                            ?>
                            <option value="<?php echo $i; ?>"
                                  <?php if($month == $i) echo 'selected'; ?>  >
                                        <?php echo get_phrase($m); ?>
                            </option>
                            <?php
                        endfor;
                        ?>
                    </select>
                 </div>
            </div>

            <div class="col-md-3">
                <div class="form-group">
                    <label class="control-label" style="margin-bottom: 5px;"><?php echo get_phrase('sessional_year'); ?></label>
                    <select class="form-control selectboxit" name="sessional_year">
                        <?php
                        $split=explode ( "." , $running_year );
                        // $sessional_year_options = explode('-', $running_year); 
                        $running_year_array = explode ( "-" , $split[1] );  ?>
                        <?php
                        $next_year_first_index          = $running_year_array[1];
                        $next_year_second_index         = $running_year_array[1]+1;
                        $new_word="";
                        $new_word2="";
                        $next_year2="";
                        $next_year3="";
                        if($split[0] == "winter"){
                            $new_word= "winter";  
                            $new_word2= "spring";  
                            $next_year2                      = $running_year_array[0]. "-" .$running_year_array[1];
                            $next_year3                      = $running_year_array[0]. "-" .$running_year_array[1];
                        }  else{
                            $new_word= "spring";  
                            $new_word2= "winter";  
                            $next_year2                      = $running_year_array[0]. "-" .$running_year_array[1];
                            $next_year3                      = $running_year_array[1]. "-" .$running_year_array[1]+1;
                        } 
                        $next_year                      = $new_word.".".$next_year2;
                        $next_year0                      = $new_word2.".".$next_year3;
                        ?>
                        
                        <option value="<?php echo $next_year; ?>"><?php echo $next_year; ?></option>
                        <option value="<?php echo $next_year0; ?>"><?php echo $next_year0; ?></option>
                    </select>
                </div>
            </div>

            <input type="hidden" name="operation" value="selection">
            <input type="hidden" name="year" value="<?php echo $running_year;?>">

        	<div class="col-md-2" style="margin-top: 20px;">
        		<button type="submit" class="btn btn-info"><?php echo get_phrase('show_report');?></button>
        	</div>
        </div>
    </div>
</div>
</form>
<table class="table">
<thead>
<tr>
<th>id</th>
<th>year</th>
<th>student</th>
<th>status</th>
</tr>
</thead>    
<tbody>
   <?php foreach($attendance->result_array() as $row): ?>
        
<tr>
<td><?php echo $row["attendance_id"]; ?></td>
<td><?php echo $row["year"]; ?></td>
<td><?php echo $row["student_id"]; ?></td>
<td><?php

echo $row["status"] == 0 ? "غياب":"حضور";

?></td>
</tr>
<?php endforeach;?>
                </tbody>    
</table>
<?php
?>